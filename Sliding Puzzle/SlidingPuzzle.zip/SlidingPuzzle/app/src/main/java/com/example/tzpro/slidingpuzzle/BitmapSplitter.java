package com.example.tzpro.slidingpuzzle;

import android.graphics.Bitmap;

public class BitmapSplitter {

    private Bitmap mOriginal;
    private Bitmap[] mSections;
    private Bitmap[] sections;
    private Bitmap bMapScaled;

    public BitmapSplitter(Bitmap bitmap) {
        mOriginal = bitmap;
        mSections = split();
    }

    public Bitmap[] getSections() {
        return mSections;
    }

    private Bitmap[] split() {

        int EasyScale = 100 ;
        int NormalScale = 75 ;
        int hardScale = 60;

        bMapScaled = Bitmap.createScaledBitmap(mOriginal, 300, 300, false);

        if(MenuActivity.LEVEL == 3){

            sections = new Bitmap[9];

            sections[0] = Bitmap.createBitmap(bMapScaled, 0,0,EasyScale,EasyScale);
            sections[1] = Bitmap.createBitmap(bMapScaled, 100,0,EasyScale,EasyScale);
            sections[2] = Bitmap.createBitmap(bMapScaled, 200,0,EasyScale,EasyScale);
            sections[3] = Bitmap.createBitmap(bMapScaled, 0,100,EasyScale,EasyScale);
            sections[4] = Bitmap.createBitmap(bMapScaled, 100,100,EasyScale,EasyScale);
            sections[5] = Bitmap.createBitmap(bMapScaled, 200,100,EasyScale,EasyScale);
            sections[6] = Bitmap.createBitmap(bMapScaled, 0,200,EasyScale,EasyScale);
            sections[7] = Bitmap.createBitmap(bMapScaled, 100,200,EasyScale,EasyScale);
            sections[8] = Bitmap.createBitmap(bMapScaled, 200,200,EasyScale,EasyScale);

        } else if(MenuActivity.LEVEL == 4){

            sections = new Bitmap[16];

            sections[0] = Bitmap.createBitmap(bMapScaled,0,0,NormalScale,NormalScale);
            sections[1] = Bitmap.createBitmap(bMapScaled,75,0,NormalScale,NormalScale);
            sections[2] = Bitmap.createBitmap(bMapScaled,150,0,NormalScale,NormalScale);
            sections[3] = Bitmap.createBitmap(bMapScaled,225,0,NormalScale,NormalScale);
            sections[4] = Bitmap.createBitmap(bMapScaled,0,75,NormalScale,NormalScale);
            sections[5] = Bitmap.createBitmap(bMapScaled,75,75,NormalScale,NormalScale);
            sections[6] = Bitmap.createBitmap(bMapScaled,150,75,NormalScale,NormalScale);
            sections[7] = Bitmap.createBitmap(bMapScaled,225,75,NormalScale,NormalScale);
            sections[8] = Bitmap.createBitmap(bMapScaled,0,150,NormalScale,NormalScale);
            sections[9] = Bitmap.createBitmap(bMapScaled,75,150,NormalScale,NormalScale);
            sections[10] = Bitmap.createBitmap(bMapScaled,150,150,NormalScale,NormalScale);
            sections[11] = Bitmap.createBitmap(bMapScaled,225,150,NormalScale,NormalScale);
            sections[12] = Bitmap.createBitmap(bMapScaled,0,225,NormalScale,NormalScale);
            sections[13] = Bitmap.createBitmap(bMapScaled,75,225,NormalScale,NormalScale);
            sections[14] = Bitmap.createBitmap(bMapScaled,150,225,NormalScale,NormalScale);
            sections[15] = Bitmap.createBitmap(bMapScaled,225,225,NormalScale,NormalScale);

        } else if (MenuActivity.LEVEL == 5){

            sections = new Bitmap[25];

            sections[0] = Bitmap.createBitmap(bMapScaled,0,0,hardScale,hardScale);
            sections[1] = Bitmap.createBitmap(bMapScaled,60,0,hardScale,hardScale);
            sections[2] = Bitmap.createBitmap(bMapScaled,120,0,hardScale,hardScale);
            sections[3] = Bitmap.createBitmap(bMapScaled,180,0,hardScale,hardScale);
            sections[4] = Bitmap.createBitmap(bMapScaled,240,0,hardScale,hardScale);
            sections[5] = Bitmap.createBitmap(bMapScaled,0,60,hardScale,hardScale);
            sections[6] = Bitmap.createBitmap(bMapScaled,60,60,hardScale,hardScale);
            sections[7] = Bitmap.createBitmap(bMapScaled,120,60,hardScale,hardScale);
            sections[8] = Bitmap.createBitmap(bMapScaled,180,60,hardScale,hardScale);
            sections[9] = Bitmap.createBitmap(bMapScaled,240,60,hardScale,hardScale);
            sections[10] = Bitmap.createBitmap(bMapScaled,0,120,hardScale,hardScale);
            sections[11] = Bitmap.createBitmap(bMapScaled,60,120,hardScale,hardScale);
            sections[12] = Bitmap.createBitmap(bMapScaled,120,120,hardScale,hardScale);
            sections[13] = Bitmap.createBitmap(bMapScaled,180,120,hardScale,hardScale);
            sections[14] = Bitmap.createBitmap(bMapScaled,240,120,hardScale,hardScale);
            sections[15] = Bitmap.createBitmap(bMapScaled,0,180,hardScale,hardScale);
            sections[16] = Bitmap.createBitmap(bMapScaled,60,180,hardScale,hardScale);
            sections[17] = Bitmap.createBitmap(bMapScaled,120,180,hardScale,hardScale);
            sections[18] = Bitmap.createBitmap(bMapScaled,180,180,hardScale,hardScale);
            sections[19] = Bitmap.createBitmap(bMapScaled,240,180,hardScale,hardScale);
            sections[20] = Bitmap.createBitmap(bMapScaled,0,240,hardScale,hardScale);
            sections[21] = Bitmap.createBitmap(bMapScaled,60,240,hardScale,hardScale);
            sections[22] = Bitmap.createBitmap(bMapScaled,120,240,hardScale,hardScale);
            sections[23] = Bitmap.createBitmap(bMapScaled,180,240,hardScale,hardScale);
            sections[24] = Bitmap.createBitmap(bMapScaled,240,240,hardScale,hardScale);
        }
        return sections;
    }
}