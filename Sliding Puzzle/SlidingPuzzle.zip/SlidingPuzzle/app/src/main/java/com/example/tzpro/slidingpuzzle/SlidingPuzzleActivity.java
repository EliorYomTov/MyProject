package com.example.tzpro.slidingpuzzle;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Locale;
import java.util.Random;

public class SlidingPuzzleActivity extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 1;
    private SharedPreferences sharedpreferences;

    Bitmap mBitmapOriginal;
    private Bitmap[] mBitmapSections;
    private int[] mBitmapSectionsPositions;

    private int mEmptyPosition;
    private int mMoveCounter;

    int imgResource = R.drawable.puzzle_img1; // default img
    int BoardSize = MenuActivity.LEVEL * MenuActivity.LEVEL;

    boolean isImgFromCamera = false;
    boolean isShuffled = false;
    boolean isBackgroundMusicOn = true;

    Bitmap cameraImg;
    Bitmap cameraImgResized;
    Button nextLevelBtn;

    ImageView cartoonImg;
    ImageView cartoonSliding;
    ImageView winPopImg;
    ImageView arrowImg;
    ImageView transparentBackground;

    TextView bestScore;
    TextView score;
    TextView shuffleFirstTv;
    TextView currentLevelTv;
    TextView gameOpening;

    RelativeLayout gameOpeningLayout;

    Animation animSlideLR;
    Animation animScale;
    Animation animWinScale;
    Animation animUpDown;
    Animation animEndToEnd;
    Animation animMulti2;

    MediaPlayer backgroundMusic;
    MediaPlayer winMusic;
    MediaPlayer puzzleMoveSound;

    ImageView imgContainer0;
    ImageView imgContainer1;
    ImageView imgContainer2;
    ImageView imgContainer3;
    ImageView imgContainer4;
    ImageView imgContainer5;
    ImageView imgContainer6;
    ImageView imgContainer7;
    ImageView imgContainer8;
    ImageView imgContainer9;
    ImageView imgContainer10;
    ImageView imgContainer11;
    ImageView imgContainer12;
    ImageView imgContainer13;
    ImageView imgContainer14;
    ImageView imgContainer15;
    ImageView imgContainer16;
    ImageView imgContainer17;
    ImageView imgContainer18;
    ImageView imgContainer19;
    ImageView imgContainer20;
    ImageView imgContainer21;
    ImageView imgContainer22;
    ImageView imgContainer23;
    ImageView imgContainer24;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(MenuActivity.LEVEL == 3) { setContentView(R.layout.sliding_puzzle_easy_layout); }
        else if(MenuActivity.LEVEL == 4) { setContentView(R.layout.sliding_puzzle_normal_layout); }
        else if(MenuActivity.LEVEL == 5) { setContentView(R.layout.sliding_puzzle_hard_layout); }

        switch (getIntent().getStringExtra("chosenPhoto")){
            case "img1": imgResource = R.drawable.puzzle_img1; break;
            case "img2": imgResource = R.drawable.puzzle_img2; break;
            case "img3": imgResource = R.drawable.puzzle_img3; break;
            case "img4": imgResource = R.drawable.puzzle_img4; break;
            default: imgResource = R.drawable.puzzle_img1;
        }

        backgroundMusic = MediaPlayer.create(this, R.raw.background_music);
        backgroundMusic.setLooping(true);
        backgroundMusic.start();

        winMusic = MediaPlayer.create(this, R.raw.winning_song);
        puzzleMoveSound = MediaPlayer.create(this, R.raw.puzzle_move_sound);

        score = findViewById(R.id.score2);
        bestScore = findViewById(R.id.bestscore2);
        sharedpreferences = getSharedPreferences("BestScore", Context.MODE_PRIVATE);
        setBestScore(-1);

        setupVisualItems();
        restartGame();
    }

    private void setupVisualItems()
    {
        gameOpening = findViewById(R.id.game_opening);
        gameOpeningLayout = findViewById(R.id.game_opening_layout);

        currentLevelTv = findViewById(R.id.level_tv);
        currentLevelTv.setVisibility(View.VISIBLE);

        nextLevelBtn = findViewById(R.id.next_level_btn);
        nextLevelBtn.setVisibility(View.INVISIBLE);

        animSlideLR = AnimationUtils.loadAnimation(this, R.anim.anim_slide_left_right2);
        animScale = AnimationUtils.loadAnimation(this, R.anim.anim_scale);
        animUpDown = AnimationUtils.loadAnimation(this, R.anim.anim_up_down);
        animEndToEnd = AnimationUtils.loadAnimation(this, R.anim.anim_slide_end_to_end);
        animWinScale = AnimationUtils.loadAnimation(this, R.anim.anim_win_scale);
        animMulti2 = AnimationUtils.loadAnimation(this, R.anim.anim_multi2);

        cartoonSliding = findViewById(R.id.cartoon_sliding_img);
        winPopImg = findViewById(R.id.win_pop_img);

        cartoonImg = findViewById(R.id.cartoon_img);
        cartoonImg.setImageResource(R.drawable.cartoon);

        arrowImg = findViewById(R.id.arrow_img);

        arrowImg.startAnimation(animUpDown);
        arrowImg.setVisibility(View.VISIBLE);

        shuffleFirstTv = findViewById(R.id.shuffle_first_Tv);

        transparentBackground = findViewById(R.id.transparent_background);
        transparentBackground.setVisibility(View.VISIBLE);

        switch (MenuActivity.LEVEL){
            case 3: {
                currentLevelTv.setText(getResources().getString(R.string.level_easy_txt));
                currentLevelTv.setTextColor(getResources().getColor(R.color.lightBlue));
                gameOpening.setText(getResources().getString(R.string.level_easy_txt));
                gameOpening.setTextColor(getResources().getColor(R.color.lightBlue));
                gameOpening.startAnimation(animEndToEnd);
                break;
            }
            case 4: {
                currentLevelTv.setText(getResources().getString(R.string.level_normal_txt));
                currentLevelTv.setTextColor(getResources().getColor(R.color.lightYellow));
                gameOpening.setText(getResources().getString(R.string.level_normal_txt));
                gameOpening.setTextColor(getResources().getColor(R.color.lightYellow));
                gameOpening.startAnimation(animEndToEnd);
                break;
            }
            case 5: {
                currentLevelTv.setText(getResources().getString(R.string.level_hard_txt));
                currentLevelTv.setTextColor(getResources().getColor(R.color.lightRed));
                gameOpening.setText(getResources().getString(R.string.level_hard_txt));
                gameOpening.setTextColor(getResources().getColor(R.color.lightRed));
                gameOpening.startAnimation(animEndToEnd);
                break;
            }
            default: {
                currentLevelTv.setText(getResources().getString(R.string.level_easy_txt));
                currentLevelTv.setTextColor(getResources().getColor(R.color.lightBlue));
                gameOpening.setText(getResources().getString(R.string.level_easy_txt));
                gameOpening.setTextColor(getResources().getColor(R.color.lightBlue));
                gameOpening.startAnimation(animEndToEnd);
            }
        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                gameOpeningLayout.setVisibility(View.INVISIBLE);
                shuffleFirstTv.startAnimation(animScale);
                shuffleFirstTv.setVisibility(View.VISIBLE);
                transparentBackground.setVisibility(View.VISIBLE);

            }
        },4200);

    }

    private void setupBitmaps() {
        Bitmap.Config conf = Bitmap.Config.ARGB_8888;
        Bitmap emptySpaceBitmap;

        if(isImgFromCamera) {
            mBitmapOriginal = cameraImgResized;
        }
        else { mBitmapOriginal = BitmapFactory.decodeResource(getResources(), imgResource); }

        mEmptyPosition = BoardSize - 1;

        if (mBitmapOriginal != null ) {
            BitmapSplitter splitter = new BitmapSplitter(mBitmapOriginal);
            mBitmapSections = splitter.getSections();
        }

        if(MenuActivity.LEVEL == 3)
        {
            emptySpaceBitmap = Bitmap.createBitmap(100, 100, conf);
            mBitmapSectionsPositions = new int[]{0,1,2,3,4,5,6,7,8};
            mBitmapSections[mEmptyPosition] = emptySpaceBitmap;
        }
        else if(MenuActivity.LEVEL == 4)
        {
            emptySpaceBitmap = Bitmap.createBitmap(75, 75, conf);
            mBitmapSectionsPositions = new int[]{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
            mBitmapSections[mEmptyPosition] = emptySpaceBitmap;
        }
        else if(MenuActivity.LEVEL == 5)
        {
            emptySpaceBitmap = Bitmap.createBitmap(60, 60, conf);
            mBitmapSectionsPositions = new int[]{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24};
            mBitmapSections[mEmptyPosition] = emptySpaceBitmap;
        }
    }

    private void setupImages() {
        if(MenuActivity.LEVEL == 3) {
            setupImageLevelEasy();
        }
        else if(MenuActivity.LEVEL == 4) {
            setupImageLevelEasy();
            setupImageLevelNormal();
        }
        else if(MenuActivity.LEVEL == 5) {
            setupImageLevelEasy();
            setupImageLevelNormal();
            setupImageLevelHard();
        }
    }

    private void setupImageLevelEasy()
    {
        imgContainer0 = findViewById(R.id.image0);
        imgContainer1 = findViewById(R.id.image1);
        imgContainer2 = findViewById(R.id.image2);
        imgContainer3 = findViewById(R.id.image3);
        imgContainer4 = findViewById(R.id.image4);
        imgContainer5 = findViewById(R.id.image5);
        imgContainer6 = findViewById(R.id.image6);
        imgContainer7 = findViewById(R.id.image7);
        imgContainer8 = findViewById(R.id.image8);

        imgContainer0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(0);
            }
        });
        imgContainer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(1);
            }
        });
        imgContainer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(2);
            }
        });
        imgContainer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(3);
            }
        });
        imgContainer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(4);
            }
        });
        imgContainer5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(5);
            }
        });
        imgContainer6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(6);
            }
        });
        imgContainer7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(7);
            }
        });
        imgContainer8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(8);
            }
        });

        imgContainer0.setImageBitmap(mBitmapSections[0]);
        imgContainer1.setImageBitmap(mBitmapSections[1]);
        imgContainer2.setImageBitmap(mBitmapSections[2]);
        imgContainer3.setImageBitmap(mBitmapSections[3]);
        imgContainer4.setImageBitmap(mBitmapSections[4]);
        imgContainer5.setImageBitmap(mBitmapSections[5]);
        imgContainer6.setImageBitmap(mBitmapSections[6]);
        imgContainer7.setImageBitmap(mBitmapSections[7]);
        imgContainer8.setImageBitmap(mBitmapSections[8]);
    }
    private void setupImageLevelNormal()
    {
        imgContainer9 = findViewById(R.id.image9);
        imgContainer10 = findViewById(R.id.image10);
        imgContainer11 = findViewById(R.id.image11);
        imgContainer12 = findViewById(R.id.image12);
        imgContainer13 = findViewById(R.id.image13);
        imgContainer14 = findViewById(R.id.image14);
        imgContainer15 = findViewById(R.id.image15);

        imgContainer9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(9);
            }
        });
        imgContainer10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(10);
            }
        });
        imgContainer11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(11);
            }
        });
        imgContainer12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(12);
            }
        });
        imgContainer13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(13);
            }
        });
        imgContainer14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(14);
            }
        });
        imgContainer15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(15);
            }
        });

        imgContainer9.setImageBitmap(mBitmapSections[9]);
        imgContainer10.setImageBitmap(mBitmapSections[10]);
        imgContainer11.setImageBitmap(mBitmapSections[11]);
        imgContainer12.setImageBitmap(mBitmapSections[12]);
        imgContainer13.setImageBitmap(mBitmapSections[13]);
        imgContainer14.setImageBitmap(mBitmapSections[14]);
        imgContainer15.setImageBitmap(mBitmapSections[15]);
    }
    private void setupImageLevelHard()
    {
        imgContainer16 = findViewById(R.id.image16);
        imgContainer17 = findViewById(R.id.image17);
        imgContainer18 = findViewById(R.id.image18);
        imgContainer19 = findViewById(R.id.image19);
        imgContainer20 = findViewById(R.id.image20);
        imgContainer21 = findViewById(R.id.image21);
        imgContainer22 = findViewById(R.id.image22);
        imgContainer23 = findViewById(R.id.image23);
        imgContainer24 = findViewById(R.id.image24);

        imgContainer16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(16);
            }
        });
        imgContainer17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(17);
            }
        });
        imgContainer18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(18);
            }
        });
        imgContainer19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(19);
            }
        });
        imgContainer20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(20);
            }
        });
        imgContainer21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(21);
            }
        });
        imgContainer22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(22);
            }
        });
        imgContainer23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                puzzleMoveSound.start();
                swap(23);
            }
        });
        imgContainer24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                swap(24);
            }
        });

        imgContainer16.setImageBitmap(mBitmapSections[16]);
        imgContainer17.setImageBitmap(mBitmapSections[17]);
        imgContainer18.setImageBitmap(mBitmapSections[18]);
        imgContainer19.setImageBitmap(mBitmapSections[19]);
        imgContainer20.setImageBitmap(mBitmapSections[20]);
        imgContainer21.setImageBitmap(mBitmapSections[21]);
        imgContainer22.setImageBitmap(mBitmapSections[22]);
        imgContainer23.setImageBitmap(mBitmapSections[23]);
        imgContainer24.setImageBitmap(mBitmapSections[24]);
    }

    private void swap(int position) {
        if (isAdjacentToEmpty(position)) {

            Bitmap tmpBitmap = mBitmapSections[position];
            mBitmapSections[position] = mBitmapSections[mEmptyPosition];
            mBitmapSections[mEmptyPosition] = tmpBitmap;

            int tmpPosition = mBitmapSectionsPositions[position];
            mBitmapSectionsPositions[position] = mBitmapSectionsPositions[mEmptyPosition];
            mBitmapSectionsPositions[mEmptyPosition] = tmpPosition;

            mEmptyPosition = position;
            setupImages();

            if (isShuffled) {
                mMoveCounter++;
                setSteps(mMoveCounter);
                checkForVictory();
            } else {
                arrowImg.setVisibility(View.VISIBLE);
                arrowImg.startAnimation(animUpDown);
            }
        }
    }

    private boolean isAdjacentToEmpty(int position) {

        boolean result = false;

        if (MenuActivity.LEVEL == 3) {

            switch (mEmptyPosition) {
                case 0: result = (position == 1 || position == 3); break;
                case 1: result = (position == 0 || position == 2 || position == 4); break;
                case 2: result = (position == 1 || position == 5); break;
                case 3: result = (position == 0 || position == 4 || position == 6); break;
                case 4: result = (position == 1 || position == 3 || position == 5 || position == 7); break;
                case 5: result = (position == 2 || position == 4 || position == 8); break;
                case 6: result = (position == 3 || position == 7); break;
                case 7: result = (position == 4 || position == 6 || position == 8); break;
                case 8: result = (position == 5 || position == 7); break;
                default: result = false;
            }
        } else if (MenuActivity.LEVEL == 4) {

            switch (mEmptyPosition) {
                case 0: result = (position == 1 || position == 4); break;
                case 1: result = (position == 0 || position == 2 || position == 5); break;
                case 2: result = (position == 1 || position == 3 || position == 6); break;
                case 3: result = (position == 2 || position == 7); break;
                case 4: result = (position == 0 || position == 5 || position == 8); break;
                case 5: result = (position == 1 || position == 4 || position == 6 || position == 9); break;
                case 6: result = (position == 2 || position == 5 || position == 7 || position == 10); break;
                case 7: result = (position == 3 || position == 6 || position == 11); break;
                case 8: result = (position == 4 || position == 9 || position == 12); break;
                case 9: result = (position == 5 || position == 8 || position == 10 || position == 13); break;
                case 10: result = (position == 6 || position == 9 || position == 11 || position == 14); break;
                case 11: result = (position == 7 || position == 10 || position == 15); break;
                case 12: result = (position == 8 || position == 13); break;
                case 13: result = (position == 9 || position == 12 || position == 14); break;
                case 14: result = (position == 10 || position == 13 || position == 15); break;
                case 15: result = (position == 11 || position == 14); break;
                default: result = false;
            }
        } else if (MenuActivity.LEVEL == 5) {
            switch (mEmptyPosition) {
                case 0: result = (position == 1 || position == 5); break;
                case 1: result = (position == 0 || position == 2 || position == 6); break;
                case 2: result = (position == 1 || position == 3 || position == 7); break;
                case 3: result = (position == 2 || position == 4 || position == 8); break;
                case 4: result = (position == 3 || position == 9); break;
                case 5: result = (position == 0 || position == 6 || position == 10); break;
                case 6: result = (position == 1 || position == 5 || position == 7 || position == 11); break;
                case 7: result = (position == 2 || position == 6 || position == 8 || position == 12); break;
                case 8: result = (position == 3 || position == 7 || position == 9 || position == 13); break;
                case 9: result = (position == 4 || position == 8 || position == 14); break;
                case 10: result = (position == 5 || position == 11 || position == 15); break;
                case 11: result = (position == 6 || position == 10 || position == 12 || position == 16); break;
                case 12: result = (position == 7 || position == 11 || position == 13 || position == 17); break;
                case 13: result = (position == 8 || position == 12 || position == 14 || position == 18); break;
                case 14: result = (position == 9 || position == 13 || position == 19); break;
                case 15: result = (position == 10 || position == 16 || position == 20); break;
                case 16: result = (position == 11 || position == 15 || position == 17 || position == 21); break;
                case 17: result = (position == 12 || position == 16 || position == 18 || position == 22); break;
                case 18: result = (position == 13 || position == 17 || position == 19 || position == 23); break;
                case 19: result = (position == 14 || position == 18 || position == 24); break;
                case 20: result = (position == 15 || position == 21); break;
                case 21: result = (position == 16 || position == 20 || position == 22); break;
                case 22: result = (position == 17 || position == 21 || position == 23); break;
                case 23: result = (position == 18 || position == 22 || position == 24); break;
                case 24: result = (position == 19 || position == 23); break;
                default: result = false;
            }
        }

        return result;
    }

    private void checkForVictory() {

        if(MenuActivity.LEVEL == 3) {
            if (Arrays.equals(mBitmapSectionsPositions, new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8})) {
                victory();
            }
        }
        else if(MenuActivity.LEVEL == 4) {
            if (Arrays.equals(mBitmapSectionsPositions, new int[]{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15})) {
                victory();
            }
        }
        else if(MenuActivity.LEVEL == 5) {
            if (Arrays.equals(mBitmapSectionsPositions, new int[]{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24})) {
                victory();
            }
        }
    }

    private void victory() {
        if(isShuffled)
        {
            cartoonImg.setVisibility(View.INVISIBLE);
            cartoonSliding.startAnimation(animSlideLR);
            cartoonSliding.setVisibility(View.VISIBLE);

            if (Locale.getDefault().getLanguage().equals("iw")) {
                winPopImg.setImageResource(R.drawable.win_pop_heb);
            }
            winPopImg.setVisibility(View.VISIBLE);
            winPopImg.startAnimation(animWinScale);

            if(MenuActivity.LEVEL == 3 || MenuActivity.LEVEL == 4) {
                currentLevelTv.setVisibility(View.INVISIBLE);
                nextLevelBtn.setVisibility(View.VISIBLE);
                nextLevelBtn.startAnimation(animMulti2);
            }
            setBestScore(mMoveCounter);
            winMusic.start();
            if (isBackgroundMusicOn) {
                backgroundMusic.pause();
                backgroundMusic.seekTo(0);
            }
            isShuffled = false;
        }
        else {
            arrowImg.setVisibility(View.VISIBLE);
            arrowImg.startAnimation(animUpDown);
        }
    }

    public void shuffleButtonClick (View v){
        MainActivity.btnSound.start();
        isShuffled = true;
        cartoonSliding.setVisibility(View.INVISIBLE);
        cartoonImg.setImageResource(R.drawable.cartoon);
        cartoonImg.setVisibility(View.VISIBLE);
        winPopImg.clearAnimation();
        winPopImg.setVisibility(View.INVISIBLE);
        nextLevelBtn.setVisibility(View.INVISIBLE);
        nextLevelBtn.clearAnimation();
        currentLevelTv.setVisibility(View.VISIBLE);

        transparentBackground.setVisibility(View.INVISIBLE);
        arrowImg.setVisibility(View.INVISIBLE);
        arrowImg.clearAnimation();
        shuffleFirstTv.setVisibility(View.INVISIBLE);

        if(winMusic != null && winMusic.isPlaying()) {
            winMusic.pause();
            winMusic.seekTo(0);
        }
        if(isBackgroundMusicOn) {
            backgroundMusic.start();
        }

        for(int i = 0; i < 3; i++)
        {
            randomizeStartingBoard();
        }

        mMoveCounter = 0;
        setSteps(mMoveCounter);
    }

    private void randomizeStartingBoard() {
        Random random = new Random();
        for (int i = 0; i < 100; i++) {
            swap(random.nextInt(BoardSize - 1));
        }
    }

    private void restartGame() {
        setupBitmaps();
        setupImages();
        isShuffled = false;
        mMoveCounter = 0;
        setSteps(mMoveCounter);
    }

    public void solveButtonClick (View v){

        MainActivity.btnSound.start();
        arrowImg.setVisibility(View.VISIBLE);
        arrowImg.startAnimation(animUpDown);

        if(isShuffled) {
            cartoonImg.setImageResource(R.drawable.cartoon_winner);
            isShuffled = false;
            restartGame();
        } else {
            mMoveCounter = 0;
            setSteps(mMoveCounter); }
    }

    public void settingButtonClick(View view){
        MainActivity.btnSound.start();

        PopupMenu popupMenu = new PopupMenu(this,view);
        popupMenu.getMenuInflater().inflate(R.menu.popup_menu,popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {

                switch (menuItem.getItemId()) {
                    case R.id.menu_next_level: {
                        if(MenuActivity.LEVEL == 5) { Toast.makeText(SlidingPuzzleActivity.this, R.string.highest_level_txt, Toast.LENGTH_SHORT).show(); }
                        else { goNextLevel(findViewById(R.id.go_back_btn)); }
                        break;
                    }
                    case R.id.menu_back: {
                        MainActivity.btnSound.start();
                        onBackPressed();
                        break; }
                }

                return false;
            }});
        popupMenu.show();

    }

    private void setSteps(int steps){
        if(steps == -1) {
            score.setText("--");
        } else {
            score.setText("" + steps);
        }
    }

    private void setBestScore(int steps){

        SharedPreferences.Editor editor = sharedpreferences.edit();
        String key = Integer.toString(MenuActivity.LEVEL);

        int bestScoreCheck = sharedpreferences.getInt(key,-1);

        if(bestScoreCheck == -1 ){
            bestScore.setText("--");
        }
        else {
            bestScore.setText("" + bestScoreCheck);
        }

        if(steps == -1){
            return ;
        }

        String tempScore = bestScore.getText().toString();

        if(tempScore.equals("--")){         //if its first win
            bestScore.setText("" + steps);
            editor.putInt(key, steps);
            editor.commit();
            return ;
        }
        int temp = Integer.parseInt(tempScore);
        if(temp > steps) {                 //wins after first win
            bestScore.setText("" + steps);
            editor.putInt(key, steps);
            editor.commit();
        }
    }

    public void goNextLevel(View view) {
        MainActivity.btnSound.start();
        if(MenuActivity.LEVEL == 3)
        {
            finish();
            MenuActivity.LEVEL = 4;
            Intent normalLevelIntent = new Intent(this, SlidingPuzzleActivity.class);
            normalLevelIntent.putExtra("chosenPhoto", getIntent().getStringExtra("chosenPhoto"));
            startActivity(normalLevelIntent);
        }
        else if(MenuActivity.LEVEL == 4){
            finish();
            MenuActivity.LEVEL = 5;
            Intent hardLevelIntent = new Intent(this, SlidingPuzzleActivity.class);
            hardLevelIntent.putExtra("chosenPhoto", getIntent().getStringExtra("chosenPhoto"));
            startActivity(hardLevelIntent);
        }
    }

    public void TakePictureIntent(View view) {
        MainActivity.btnSound.start();
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK ){
            cameraImg = (Bitmap) data.getExtras().get("data");
            if(cameraImg != null){
                cameraImgResized = Bitmap.createBitmap(cameraImg, 0, 0, cameraImg.getWidth(), cameraImg.getWidth());
                isImgFromCamera = true;
                restartGame();

                cartoonSliding.setVisibility(View.INVISIBLE);
                cartoonImg.setVisibility(View.VISIBLE);
                winPopImg.clearAnimation();
                winPopImg.setVisibility(View.INVISIBLE);
                nextLevelBtn.clearAnimation();
                nextLevelBtn.setVisibility(View.INVISIBLE);
                currentLevelTv.setVisibility(View.VISIBLE);
                shuffleFirstTv.setVisibility(View.VISIBLE);
                transparentBackground.setVisibility(View.VISIBLE);
                arrowImg.setVisibility(View.VISIBLE);
                arrowImg.startAnimation(animUpDown);
            }
        } else {
            Toast.makeText(getApplicationContext(),R.string.img_not_selected,Toast.LENGTH_SHORT).show(); }
    }

    @Override
    public void onBackPressed() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();

        final View dialogView  = inflater.inflate(R.layout.go_back_dialog,null,false);
        builder.setView(dialogView);

        final Button yesBtn = dialogView.findViewById(R.id.btn_yes);
        final Button noBtn = dialogView.findViewById(R.id.btn_no);

        yesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                finish();
            }
        });

        final AlertDialog dialog = builder.create();
        noBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                dialog.cancel();
            }
        });
        dialog.show();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        if(v.getId() == R.id.go_back_btn)
            getMenuInflater().inflate(R.menu.popup_menu,menu);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // adds items to the action bar
        getMenuInflater().inflate(R.menu.menu_puzzle, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_sound: {
                if (isBackgroundMusicOn) {
                    backgroundMusic.pause();
                    isBackgroundMusicOn = false;
                    item.setTitle(getResources().getString(R.string.sound_off_menu));
                }
                else {
                    backgroundMusic.start();
                    isBackgroundMusicOn = true;
                    item.setTitle(getResources().getString(R.string.sound_on_menu));
                }
                break;
            }
            case R.id.action_how_to_play:
            {
                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                LayoutInflater inflater = getLayoutInflater();

                final View howToPlayDialogView = inflater.inflate(R.layout.how_to_play_dialog,null,false);
                builder.setView(howToPlayDialogView);

                final AlertDialog dialog = builder.create();
                final Button BackBtn = howToPlayDialogView.findViewById(R.id.btn_back);

                BackBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        MainActivity.btnSound.start();
                        dialog.cancel();
                    }
                });
                dialog.show();
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {

       if(isBackgroundMusicOn) { backgroundMusic.start(); }

        if(winMusic != null && winMusic.isPlaying()){
            winMusic.start();
        }
        super.onStart();
    }

    @Override
    protected void onPause() {
        if(isBackgroundMusicOn) { backgroundMusic.pause(); }

        if(winMusic != null && winMusic.isPlaying()) {
            winMusic.pause();
            winMusic.seekTo(0);
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        backgroundMusic.stop();
        backgroundMusic.release();

        if(winMusic != null) {
            winMusic.stop();
            winMusic.release();
        }
        super.onDestroy();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        shuffleFirstTv.setVisibility(View.INVISIBLE);
        arrowImg.setVisibility(View.INVISIBLE);
        arrowImg.clearAnimation();
        transparentBackground.setVisibility(View.INVISIBLE);
        return super.onTouchEvent(event);
    }
}