package com.example.tzpro.slidingpuzzle;


import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    AnimationDrawable backgroundAnimationDrawable;
    AnimationDrawable cartoonAnimationDrawable;
    AnimationDrawable cartoonHelloAnimationDrawable;

    MediaPlayer backgroundMusic;
    public static MediaPlayer btnSound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button enterBtn = findViewById(R.id.enter_btn);
        final Button exitBtn = findViewById(R.id.exit_btn);
        final EditText nameEt = findViewById(R.id.name_et);
        final ImageView logoIv = findViewById(R.id.logo_iv);
        final ImageView trailIv = findViewById(R.id.trail_iv);
        final ImageView cartoonImg = findViewById(R.id.cartoon_wave);
        final ImageView cartoonHello = findViewById(R.id.cartoon_hello);

        final MediaPlayer hiVoice = MediaPlayer.create(this, R.raw.hi_sound);

        final Animation animSlideLR = AnimationUtils.loadAnimation(this, R.anim.anim_slide_left_right);
        final Animation animSlideRL = AnimationUtils.loadAnimation(this, R.anim.anim_slide_right_left);
        final Animation animAlpha = AnimationUtils.loadAnimation(this, R.anim.anim_alpha);
        final Animation animUpDown2 = AnimationUtils.loadAnimation(this, R.anim.anim_up_down2);
        final Animation animSlideRL2 = AnimationUtils.loadAnimation(this, R.anim.anim_slide_right_left2);

        final RelativeLayout mainLayout = findViewById(R.id.main_layout);
        backgroundAnimationDrawable = (AnimationDrawable) mainLayout.getBackground();
        backgroundAnimationDrawable.setEnterFadeDuration(3000);
        backgroundAnimationDrawable.setExitFadeDuration(3000);

        cartoonHelloAnimationDrawable = (AnimationDrawable) cartoonHello.getBackground();
        cartoonHelloAnimationDrawable.setEnterFadeDuration(0);
        cartoonHelloAnimationDrawable.setExitFadeDuration(0);

        cartoonAnimationDrawable = (AnimationDrawable) cartoonImg.getBackground();
        cartoonAnimationDrawable.setEnterFadeDuration(0);
        cartoonAnimationDrawable.setExitFadeDuration(0);

        cartoonHello.startAnimation(animSlideLR);
        logoIv.startAnimation(animSlideRL);

        nameEt.setVisibility(View.INVISIBLE);
        enterBtn.setVisibility(View.INVISIBLE);
        exitBtn.setVisibility(View.INVISIBLE);
        trailIv.setVisibility(View.INVISIBLE);
        cartoonImg.setVisibility(View.INVISIBLE);

        hiVoice.start();

        backgroundMusic = MediaPlayer.create(this, R.raw.background_music_menu);
        backgroundMusic.setLooping(true);
        backgroundMusic.start();

        btnSound = MediaPlayer.create(this, R.raw.button_sound);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                cartoonHello.startAnimation(animSlideRL2);
            }
        },2800);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                cartoonHello.setVisibility(View.INVISIBLE);
                nameEt.setVisibility(View.VISIBLE);
                enterBtn.setVisibility(View.VISIBLE);
                exitBtn.setVisibility(View.VISIBLE);
                trailIv.setVisibility(View.VISIBLE);
                cartoonImg.setVisibility(View.VISIBLE);
                nameEt.startAnimation(animUpDown2);
                enterBtn.startAnimation(animUpDown2);
                exitBtn.startAnimation(animUpDown2);
                trailIv.startAnimation(animAlpha);
                cartoonImg.startAnimation(animSlideLR);
            }
        },4000);

        enterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnSound.start();
                String name = nameEt.getText().toString();
                if(name.isEmpty()) {
                    Toast.makeText(MainActivity.this, R.string.enter_name_hint, Toast.LENGTH_SHORT ).show();
                } else {
                    Intent enterIntent = new Intent(MainActivity.this, MenuActivity.class);
                    enterIntent.putExtra("userName", name);
                    startActivity(enterIntent);
                }
            }
        });

        exitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnSound.start();
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (backgroundAnimationDrawable != null && !backgroundAnimationDrawable.isRunning()) {
            backgroundAnimationDrawable.start();
        }

        if (cartoonAnimationDrawable != null && !cartoonAnimationDrawable.isRunning()) {
            cartoonAnimationDrawable.start();
        }

        if (cartoonHelloAnimationDrawable != null && !cartoonHelloAnimationDrawable.isRunning()) {
            cartoonHelloAnimationDrawable.start();
        }

        backgroundMusic.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (backgroundAnimationDrawable != null && backgroundAnimationDrawable.isRunning()) {
            backgroundAnimationDrawable.stop();
        }

        if (cartoonAnimationDrawable != null && cartoonAnimationDrawable.isRunning()) {
            cartoonAnimationDrawable.stop();
        }

        if (cartoonHelloAnimationDrawable != null && cartoonHelloAnimationDrawable.isRunning()) {
            cartoonHelloAnimationDrawable.stop();
        }

        backgroundMusic.pause();
    }

    @Override
    protected void onStart() {
        backgroundMusic.start();
        super.onStart();
    }

    @Override
    protected void onDestroy() {
        backgroundMusic.stop();
        backgroundMusic.release();
        super.onDestroy();
    }
}
