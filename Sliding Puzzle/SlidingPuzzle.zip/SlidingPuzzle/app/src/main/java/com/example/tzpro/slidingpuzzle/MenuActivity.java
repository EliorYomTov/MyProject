package com.example.tzpro.slidingpuzzle;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MenuActivity extends AppCompatActivity {

    public static int LEVEL = 3;
    public String chosenPhoto ="img1";
    private AnimationDrawable backgroundAnimationDrawable;
    private AnimationDrawable cartoonThinkAnimationDrawable;

    MediaPlayer backgroundMusic;
    boolean isBackgroundMusicOn = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_layout);

        final Button howToPlayBtn = findViewById(R.id.how_to_play_btn);
        final Button levelEasyBtn = findViewById(R.id.easy_btn);
        final Button levelNormalBtn = findViewById(R.id.normal_btn);
        final Button levelHardBtn = findViewById(R.id.hard_btn);
        final Button backBtn = findViewById(R.id.back_btn);
        final TextView helloTv = findViewById(R.id.hello_txt);
        final TextView selectLevelTv = findViewById(R.id.select_level_txt);
        final ImageView cartoonImg = findViewById(R.id.cartoon);
        final ImageView thinkMarkImg = findViewById(R.id.think_img);
        final ImageView logoImg = findViewById(R.id.logo_iv);
        final RelativeLayout menuLayout = findViewById(R.id.menu_layout);
        final Animation animMulti = AnimationUtils.loadAnimation(this, R.anim.anim_multi);
        final Animation animAlpha = AnimationUtils.loadAnimation(this, R.anim.anim_alpha);
        final Animation animScale = AnimationUtils.loadAnimation(this, R.anim.anim_scale);
        final Animation animRotate = AnimationUtils.loadAnimation(this, R.anim.anim_rotate);
        final Animation animLR = AnimationUtils.loadAnimation(this, R.anim.anim_slide_left_right3);
        final Animation animLR2 = AnimationUtils.loadAnimation(this, R.anim.anim_slide_left_right4);
        final Animation animRL2 = AnimationUtils.loadAnimation(this, R.anim.anim_slide_right_left4);

        helloTv.setText(getResources().getText(R.string.hello_txt)+ " " + getIntent().getStringExtra("userName"));
        helloTv.startAnimation(animLR);
        selectLevelTv.startAnimation(animLR);
        logoImg.startAnimation(animRotate);
        cartoonImg.startAnimation(animAlpha);
        thinkMarkImg.startAnimation(animScale);
        levelEasyBtn.startAnimation(animMulti);
        levelNormalBtn.startAnimation(animMulti);
        levelHardBtn.startAnimation(animMulti);
        howToPlayBtn.startAnimation(animLR2);
        backBtn.startAnimation(animRL2);

        backgroundMusic = MediaPlayer.create(this, R.raw.background_music_menu);
        backgroundMusic.setLooping(true);
        backgroundMusic.start();

        backgroundAnimationDrawable = (AnimationDrawable) menuLayout.getBackground();
        backgroundAnimationDrawable.setEnterFadeDuration(3000);
        backgroundAnimationDrawable.setExitFadeDuration(3000);

        cartoonThinkAnimationDrawable = (AnimationDrawable) thinkMarkImg.getBackground();
        cartoonThinkAnimationDrawable.setEnterFadeDuration(500);
        cartoonThinkAnimationDrawable.setExitFadeDuration(500);

        howToPlayBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                final AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this);
                LayoutInflater inflater = getLayoutInflater();

                final View howToPlayDialogView = inflater.inflate(R.layout.how_to_play_dialog,null,false);
                builder.setView(howToPlayDialogView);

                final AlertDialog dialog = builder.create();
                final Button BackBtn = howToPlayDialogView.findViewById(R.id.btn_back);

                BackBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        MainActivity.btnSound.start();
                        dialog.cancel();
                    }
                });
                dialog.show();
            }
        });

        levelEasyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                LEVEL = 3; // 3X3 board layout
                pickPuzzlePhoto();
            }
        });

        levelNormalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                LEVEL = 4; // 4X4 board layout
                pickPuzzlePhoto();
            }
        });

        levelHardBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                LEVEL = 5; // 5X5 board layout
                pickPuzzlePhoto();
            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                finish();
            }
        });
    }

    public void pickPuzzlePhoto()
    {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();

        final View puzzlePhotosDialogView = inflater.inflate(R.layout.puzzle_photos_dialog,null,false);
        builder.setView(puzzlePhotosDialogView);

        final ImageButton img1 = puzzlePhotosDialogView.findViewById(R.id.img1);
        final ImageButton img2 = puzzlePhotosDialogView.findViewById(R.id.img2);
        final ImageButton img3 = puzzlePhotosDialogView.findViewById(R.id.img3);
        final ImageButton img4 = puzzlePhotosDialogView.findViewById(R.id.img4);
        final Button okBtn = puzzlePhotosDialogView.findViewById(R.id.btn_ok);
        final Button cancelBtn = puzzlePhotosDialogView.findViewById(R.id.btn_cancel);

        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                img1.setPadding(15,15,15,15);
                img2.setPadding(0,0,0,0);
                img3.setPadding(0,0,0,0);
                img4.setPadding(0,0,0,0);
                chosenPhoto = "img1";
            }
        });

        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                img1.setPadding(0,0,0,0);
                img2.setPadding(15,15,15,15);
                img3.setPadding(0,0,0,0);
                img4.setPadding(0,0,0,0);
                chosenPhoto = "img2";
            }
        });

        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                img1.setPadding(0,0,0,0);
                img2.setPadding(0,0,0,0);
                img3.setPadding(15,15,15,15);
                img4.setPadding(0,0,0,0);
                chosenPhoto = "img3";
            }
        });

        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                img1.setPadding(0,0,0,0);
                img2.setPadding(0,0,0,0);
                img3.setPadding(0,0,0,0);
                img4.setPadding(15,15,15,15);
                chosenPhoto = "img4";
            }
        });

        final AlertDialog dialog = builder.create();

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                startGame(chosenPhoto);
                chosenPhoto = "img1";
                dialog.cancel();
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.btnSound.start();
                chosenPhoto = "img1";
                dialog.cancel();
            }
        });
        dialog.show();
    }

    public void startGame(String chosenPhoto){

            Intent intent = new Intent(this, SlidingPuzzleActivity.class);
            intent.putExtra("chosenPhoto", chosenPhoto);
            startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_puzzle, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_sound: {
                if (isBackgroundMusicOn) {
                    backgroundMusic.pause();
                    isBackgroundMusicOn = false;
                    item.setTitle(getResources().getString(R.string.sound_off_menu));
                }
                else {
                    backgroundMusic.start();
                    isBackgroundMusicOn = true;
                    item.setTitle(getResources().getString(R.string.sound_on_menu));
                }
                break;
            }
            case R.id.action_how_to_play:
            {
                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                LayoutInflater inflater = getLayoutInflater();

                final View howToPlayDialogView = inflater.inflate(R.layout.how_to_play_dialog,null,false);
                builder.setView(howToPlayDialogView);

                final AlertDialog dialog = builder.create();
                final Button BackBtn = howToPlayDialogView.findViewById(R.id.btn_back);

                BackBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.cancel();
                    }
                });
                dialog.show();
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (backgroundAnimationDrawable != null && !backgroundAnimationDrawable.isRunning()) {
            backgroundAnimationDrawable.start();
        }
        if (cartoonThinkAnimationDrawable != null && !cartoonThinkAnimationDrawable.isRunning()) {
            cartoonThinkAnimationDrawable.start();
        }

        if(isBackgroundMusicOn) { backgroundMusic.start(); }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (backgroundAnimationDrawable != null && backgroundAnimationDrawable.isRunning()) {
            backgroundAnimationDrawable.stop();
        }
        if (cartoonThinkAnimationDrawable != null && !cartoonThinkAnimationDrawable.isRunning()) {
            cartoonThinkAnimationDrawable.stop();
        }

        if(isBackgroundMusicOn) { backgroundMusic.pause(); }
    }

    @Override
    protected void onStart() {
        if(isBackgroundMusicOn) { backgroundMusic.start(); }

        super.onStart();
    }

    @Override
    protected void onDestroy() {
        backgroundMusic.stop();
        backgroundMusic.release();
        super.onDestroy();
    }

}